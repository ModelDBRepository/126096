
7/31/04 PCN       AM model ["A phenomenological model of peripheral and central
		 	     neural responses to amplitude-modulated tones,"
			     Nelson, P.C., and Carney, L.H., JASA 116 (2004)]


The AN model is C code (from Xuedong Zhang), compiled and called from MATLAB. 
The VCN and IC model cell code is entirely in MATLAB.


test.m and test_FD.m are start-up examples


***************************************************************************************

This portion of the readme file for the AN model portion was modified from:
7/21/01 LHC	  ARLO model for EARLAB website


This is C code (prepared by Xuedong Zhang) for the AN model described in 
"Auditory nerve model for predicting performance limits 
of normal and impaired listeners," Heinz, M.G., Zhang, X., Bruce, I.C., 
and Carney, L.H. ARLO (2001) 2:91-96.

This code is written in C, such that it is compatible with MATLAB.

After loading all of these files into your directory,
In Matlab, type: compile_ARLO 
     to create a mex file (an_arlo_newsyn) that can be called as a Matlab function.

Run TEST.m in matlab to test the model - this code provides a simple example.

The basic call to the model is as follows:

>> an_sout = an_arlo_newsyn([tdres,cf,spontrate,model,species,ifspike,shift],sig');


where 'an_sout' is the synapse output (in sp/sec) as described in JASA 2001 and ARLO 2001.

Note the following INPUT parameters are required to run the model:

tdres: is the time-domain resolution of the input stimulus waveform in seconds-
    this sets the temporal resolution that is used throughout the model.
cf: is the characteristic frequency of a single AN fiber, in Hz.
spont: is spontaneous rate, in sp/sec
model: refers to the version of the model used, as follows:
	Model numbers as used in ARLO Heinz et al., Fig. 4 -
	1: Nonlinear_w/compression & suppression (model for 'healthy' ear)
	2: Nonlinear_w/compression, but without off-frequency suppression
        3: Linear sharp
        4: Linear broad, low threshold
        5: Linear broad, high threshold
species: refers to the species modeled -
    where 0 = human (as in ARLO paper)
          9 = cat, all CFs (as in JASA 2001 Zhang et al., paper)  
          1 = cat, only low CFs (as in Carney '93 JASA paper - not recommended)
ifspike: is a flag related to whether or not spikes are generated.
    if ifspike = 0, the sout is scaled to yield appropriate 
	average rates _without_ refractoriness (as in ARLO)    
    if ifspike = 1, the sout is scaled to yield appropriate 
	average rates _with_ refractoriness 
    There are no spikes generated in Nelson & Carney (2004) (i.e., ifspike = 0). 

Finally, sig is an array that holds the stimulus waveform, scaled in pascals and
 	sampled at the resolution specified in the input parameter tdres.


To generate spike times, 
the function call is:
>> [sptime,nspikes] = sgmodel([tdres, nrep],sout);
   where tdres is the same as above, and nrep is the number of repetitions.
(This function runs fine in Matlab6 version 12, had problems in Matlab5.3.)

See ARLO (2001) code, available at earlab.bu.edu for an example program that generates
spikes and PST histograms.


<END modified readme from ARLO AN model code>

****************************************************************************************

The remainder of this file describes the CN and IC model stages

Parameters for the model cells are defined in comments throughout test.m and test_FD.m.

Key parameters for varying AM rate-tuning properties of model IC cells are:
tau_ex_ic : Excitatory time constant of IC membrane + channels
tau_inh_ic : Inhibitory time constant of IC membrane + channels
inh_str_ic : Strength of inhibitory input (re: excitation)

Other parameters:
tau_ex_cn : Exciatory tau for CN membrane + channels
tau_inh_cn : Inhibitory tau for CN membrane + channels
cn_delay : fixed time delay of inhibitory input to CN cell (wrt excitatory input)
afamp_cn : area of CN cell alpha functions (or low-pass filter pass-band gain)
ic_delay : fixed time delay of inhibitory input to IC cell (wrt excitatory input)
afamp_ic : area of IC cell alpha functions (or low-pass filter pass-band gain)

The time-domain convolution illustrated in test.m is computationally intensive.
The frequency-domain equivalent is much faster; see test_FD.m.
Both files will produce exactly the same responses.

GOOD LUCK.  Paul Nelson & Laurel Carney
