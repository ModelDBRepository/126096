#ifndef _synapse_h
#define _synapse_h
typedef struct __tsynapse Tsynapse;
struct __tsynapse{
  double (*run)(Tsynapse *p,double x);
  void (*run2)(Tsynapse *p, const double *in, double *out, const int length);
  double cf,tdres;
  double spont;  
  double PTS, Ass, Ar_over_Ast, Pimax, tauR, tauST;
  double Prest,PPIlast,PL,PG,CIrest,CIlast,CLrest,CLlast,CG,VI,VL;
  int ifspike; /* This is important for the new synapse */
  double Vsat;
  double shift; /* This value is added to Satisfy Xuedong Zhang's modification */
  double shift2; /* Downshift, now we can make the shift asymmetrical */
};
int ihcmodel(double tdres,double cf,double spont,const double *in, double *out, int length);
int runSynapse(Tsynapse *pthis, const double *in, double *out, const int length);
void runsyn_dynamic(Tsynapse *pthis, const double *in, double *out, const int length);
double run1syn_dynamic(Tsynapse *pthis, double x);
int initSynapse(Tsynapse *pthis);
int ihc_nl(Tsynapse *pthis, const double *in, double *out, const int length);

#endif


