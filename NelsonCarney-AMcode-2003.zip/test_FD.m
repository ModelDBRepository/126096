% Example call to generate AN, CN, and IC model responses for a SAM tone

% Be sure to compile the AN model first!
% (by first running compile_ARLO in this directory)

% A frequency-domain (FD) implementation of the alpha function convolution is
% included in this version (much faster, especially for long time
% constants!)  Thanks to Mike Anzalone for help with this.

clear all

% STIMULUS PARAMETERS:
fs = 70000;             % sampling rate (Hz)
Dur = 300e-3;           % signal duration (sec)
npts = Dur * fs;        % number of points in stimulus waveform
fc = 8000;              % carrier (audio) frequency
dBSPL = 30;             % SPL (dB re: 20uPa)
m = 1;                  % SAM modulation depth  
fm = 64;                % SAM modulation frequency (Hz)


% AN MODEL PARAMETERS:
tdres = 1 / fs;       % time domain resolution (seconds)
cf=fc;                % model CF = stimulus carrier frequency
spontrate = 50;       % spontaneous rate (sp/sec)    
model = 3;            % model version (see README) 
                      % model=3 was used in Nelson & Carney (2004)
species = 9;             % species (=0 for human, =9 for cat)
ifspike = 0;          % flag for scaling to generate spikes or not
shift = 2*spontrate;  % magnitude of 'shift' in new synapse model

% CN MODEL PARAMETERS:
tau_ex_cn = .5e-3;         % CN exc time constant
tau_inh_cn = 2e-3;         % CN inh time constant
cn_delay = 1e-3;        % "disynaptic inhibition delay" (all ANFs excitatory)
inh_str_cn = 0.6;       % re: excitatory strength == 1
afamp_cn = 1.5;         % alpha function area --> changes RATE of output cell

% IC MODEL PARAMETERS:
tau_ex_ic = 1e-3;       % IC exc time constant
tau_inh_ic = 3e-3;      % IC inh tune constant
ic_delay = 0.002;       % delay along inhibitory pathway
inh_str_ic = 1.5;       % re: exc strength == 1
afamp_ic = 1;           % alpha function area --> changes RATE of output cell


% window time domain waveform
rampdur = 5e-3;         % duration of cos-squared onset/offset (sec)
rampts = fs * rampdur;
step = pi/(rampts-1);
x=[0:step:pi];
offramp = (1+cos(x))./2;
onramp = (1+cos(fliplr(x)))./2;
steadypts = npts - 2*rampts;
o=ones(1,steadypts);
wholeramp = [onramp o offramp]; % Envelope for stimulus (i.e. on/off ramps)
%%%%%%%%%%%%%%%

amp = 10^(-(94-dBSPL)/20);  % for scaling stimuli into Pascals
t = [0:npts-1]/fs;      % stimulus time vector


stim1 = (sqrt(2))*amp*sin(2*pi*fc*t);
tone = wholeramp.*stim1;               % pure tone
modulator = m*sin(2*pi*fm*t);
stim2 = ((1 + modulator).*(stim1));
am_tone = (sqrt(mean(stim1.^2))/sqrt(mean(stim2.^2)))*wholeramp.*stim2;   % SAM tone (scaled to same rms as pure tone)


% Call AN model:
an_sout = an_arlo_newsyn([tdres,cf,spontrate,model,species,ifspike,shift],am_tone);  % for SAM tone


% Generate frequency-domain equivalent of alpha functions
[B1, A1] = get_alpha_norm(tau_ex_cn, fs, 1);
[B2, A2] = get_alpha_norm(tau_inh_cn, fs, 1);

cn_ex = [afamp_cn*(1/fs)*(filter(B1, A1, [an_sout])) zeros(1,fs*cn_delay)];
cn_inh = [zeros(1,fs*cn_delay) afamp_cn*inh_str_cn*(1/fs)*(filter(B2, A2, [an_sout]))];

% final CN model response:
cn_sout = ((cn_ex-cn_inh) + abs(cn_ex-cn_inh))/2;   % subtract inhibition from excitation and half-wave-rectify
cn_t = [0:(length(cn_sout)-1)]/fs;        % time vector for plotting CN responses



% Generate alpha functions for IC model (same as CN model, but with different taus):
[B3, A3] = get_alpha_norm(tau_ex_ic, fs, 1);
[B4, A4] = get_alpha_norm(tau_inh_ic, fs, 1);

ic_lp_ex1 = [afamp_ic*(1/fs)*(filter(B3, A3, [cn_sout])) zeros(1,fs*ic_delay)];
ic_lp_inh1 = [zeros(1,fs*ic_delay) afamp_ic*inh_str_ic*(1/fs)*(filter(B4, A4, [cn_sout]))];

% final IC model response:
ic_sout = ((ic_lp_ex1-ic_lp_inh1) + abs(ic_lp_ex1-ic_lp_inh1))/2;
ic_t = [0:(length(ic_sout)-1)]/fs;

figure
subplot(411);plot(t,am_tone);ylabel('STIMULUS');axis([0 Dur+.025 1.1*min(am_tone) 1.1*max(am_tone)])
subplot(412);plot(t,an_sout);ylabel('AN SOUT');axis([0 Dur+.025 0 1.1*max(an_sout)])
subplot(413);plot(cn_t,cn_sout);ylabel('CN SOUT');axis([0 Dur+.025 0 1.1*max(cn_sout)])
subplot(414);plot(ic_t,ic_sout);ylabel('IC SOUT');axis([0 Dur+.025 0 1.1*max(ic_sout)]);xlabel('time (sec)')
