/* vim: set ts=4: */
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "cmpa.h"
#include "synapse.h"
#include "filters.h"

/* #define ZXD_DEBUG */

extern FILE *fdebug;
void initAuditoryNerveNew2(TAuditoryNerve *p,int model, int species, double tdres, double cf, double spont,double sp_shift);
/* First we force the ppi cann't be larger than 2*PIMAX (if spikes = 0)
 * */
void initAuditoryNerveNew(TAuditoryNerve *p,int model, int species, double tdres, double cf, double spont){
	 initAuditoryNerveNew2(p,model,species,tdres,cf,spont,2*spont);
};
void initAuditoryNerveNew2(TAuditoryNerve *p,int model, int species, double tdres, double cf, double spont,double sp_shift)
{ /* default */
  Tsynapse *syn;

  double Kcf,temp;
  double p1,p2,pst,psl;

  p->run = runAN;
  p->run2 = runAN2;

  syn = &(p->syn);

  p->model = model;
  p->species = species;
  p->cf = cf;
  p->spont = spont;
  p->tdres = tdres;

  p->run = runAN;
  p->run2 = runAN2;
  /*
   * Init the basilar membrane
   * */
  initBasilarMembrane(&(p->bm),model,species,tdres,cf);

  /* Now add support for different species */

  /* This line tries to output the appropriate sout rate base on spikes/sout */
  syn->ifspike = p->ifspike;
  if(p->ifspike==1) syn->Ass = 350;
  else syn->Ass = 130; /* borrow this for Mike G. Heinz */
  switch(species)
  { 
	  case 1 : /* Cat */
	  case 9 : /* Universal */
		  /*
		   * Init the synapse
		   * */
		  syn->tdres = tdres;
		  syn->cf = cf;
		  syn->spont = spont;
		  syn->Pimax = 0.6;
		  syn->PTS = 1+9*spont/(9+spont);
/*/		  syn->Ass = 350; */
		  syn->Ar_over_Ast = 6.0;
		  syn->tauR = 0.002;
		  syn->tauST = 0.060;
		  initSynapseNew2(syn,sp_shift);  /*This function calcuate all other parameters as described in the appendix*/

		  /*
		   * Init the ihcppi rectify function and parameters
		   * !!!!Use the result from initSynapse(syn)
		   *
		   * */
 	  	  Kcf = 2.0+3.0*log10(cf/1000);
		  if(Kcf<1.5) Kcf = 1.5;
		  syn->Vsat = syn->Pimax*Kcf*20.0*(1+spont)/(5+spont);
		  /* Important !!! The original code seems use the following equation!!!
		     This is not shown in the paper but Prest is very small compare to the other part < 0.01*Vsat
		     and the results is the same
		   */
		  /* syn->Vsat = syn->Pimax*Kcf*20.0*(1+spont)/(5+spont)+syn->Prest; */
		  
		  break;
	  case 0 :
	  default: /* Human */
		  /*
		   * Init the synapse
		   * */
		  syn->tdres = tdres;
		  syn->cf = cf;
		  syn->spont = spont;
		  syn->Pimax = 0.6;
		  /*  syn->PTS = 8.627;  This is for SPONT=50 */
		  syn->PTS = 1+9*spont/(9+spont);   /* Peak to Steady State Ratio, characteristic of PSTH */

/*/		  syn->Ass = 130; */
		  syn->Ar_over_Ast = 6.0;
		  syn->tauR = 0.002;
		  syn->tauST = 0.060;
		  initSynapseNew2(syn,sp_shift);  /*This function calcuate all other parameters as described in the appendix*/

		  /*
		   * Init the ihcppi rectify function and parameters
		   * !!!!Use the result from initSynapse(syn)
		   *
		   * */
            	  Kcf = 2.0+1.3*log10(cf/1000); /*/ From M. G. Heinz */
		  if(Kcf<1.5) Kcf = 1.5;
		  syn->Vsat = syn->Pimax*Kcf*60.0*(1+spont)/(6+spont);
		  /* Important !!! The original code seems use the following equation!!!
		     This is not shown in the paper but Prest is very small compare to the other part < 0.01*Vsat
		     and the results is the same, so we use the upper equation
		   */
		  /* syn->Vsat = syn->Pimax*Kcf*60.0*(1+spont)/(6+spont)+syn->Prest; */
		  
		  break;
  };
  temp = log(2)*syn->Vsat/syn->Prest;
  if(temp<400) pst = log(exp(temp)-1);
  else pst = temp;
  psl = syn->Prest*pst/log(2);
  p2 = pst;
  p1 = psl/pst;

#ifdef DEBUG
  printf("\ninitSyanpse : p1=%f; p2=%f",p1,p2);
#endif
  
  p->ihcppi.psl = psl;
  p->ihcppi.pst = pst;
  p->ihcppi.p1 = p1;
  p->ihcppi.p2 = p2;
  p->ihcppi.run = runIHCPPI;	/*These are functions used to get ihcppi output */
  p->ihcppi.run2 = runIHCPPI2;  /*Defined in hc.c, hc.h */

  /* 
   * Init Inner Hair Cell Model
   */
  /* For Human Only !!!!!!! Hair Cell low pass filter (tdres,cutoff,gain,order) */
  switch(species)
  {
	case 0:
	default: /* Human */
	  initLowPass(&(p->ihc.hclp),tdres,4500.0,1.0,7);
	  break;
	case 1:  /* Cat, this version use the Laurel's revcor data to determine taumin, taumax */
	case 9:  /* Also for universal CAT; as in AN2 */
	  initLowPass(&(p->ihc.hclp),tdres,3800.0,1.0,7);
	  break;
  };
  p->ihc.run = runHairCell;
  p->ihc.run2 = runHairCell2;
  p->ihc.hcnl.A0 = 0.1;  /* Inner Hair Cell Nonlinear Function */
  p->ihc.hcnl.B = 2000.;
  p->ihc.hcnl.C = 1.74;
  p->ihc.hcnl.D = 6.87e-9;
  p->ihc.hcnl.run = runIHCNL;
  p->ihc.hcnl.run2 = runIHCNL2;
return;
}

/*
 * This is only soft-rectifier, no low-pass
 * */
void runsyn_dynamicNew(Tsynapse *pthis, const double *in, double *out, int length)
{
  int error;
  int register i;
  double shift;
  static double p1=1.0; /* put soft rectifier here, since the shift is equal to spont here */
  double temp;
  
  runsyn_dynamic(pthis,in,out,length);  

  /* Soft rectfying the sout (Cann't go to negative) */
  if(pthis->spont > 5) p1 = 1;
  else p1 = 5/pthis->spont; /* Soft rectifying of sout */
  shift = pthis->shift;

  for(i = 0; i<length;i++){
    temp = out[i]-shift;
	if(p1*temp>100)
		out[i] = temp;
	else
		out[i] = log(1+exp(p1*temp))/p1;
  };

return;
};
/* This function is not used */
void runsyn_dynamicNew_Lowpass(Tsynapse *pthis, const double *in, double *out, int length)
{
  int error;
  int register i;
  double shift;
  static double p1=1.0; /* put soft rectifier here, since the shift is equal to spont here */
  double temp;
  double Pimax;
  static TLowPass syn_lowpass;

  shift = pthis->shift;

  /* First We limit the max of Pimax (applied to ifspike = 0) */
  if(pthis->ifspike == 5) /* Only apply for non spikes model; Method 1 : limit the Pimax */
  {
      if(pthis->spont > 5) p1 = 1;
      else p1 = 5/pthis->spont; /* Soft rectifying of sout */
	  Pimax = pthis->Pimax;
	  for(i = 0; i<length;i++){
    	if (in[i] > Pimax)
			out[i] = 2*Pimax - Pimax/10*log(1+exp(2*Pimax-in[i])*10/Pimax);
		else
			out[i] = in[i]; /* out[i] = in[i];*/
/*    	if (in[i] > Pimax)
 *			out[i] = 4*Pimax - Pimax/4*log(1+exp(4*Pimax-in[i])*4/Pimax);
			out[i] = Pimax;
		else
			out[i] = in[i]; 
*/
	  };
#ifdef ZXD_DEBUG
	  fprintf(fdebug,"ifspike = %d", pthis->ifspike);
#endif
      runsyn_dynamic(pthis,out,out,length);
  } else {
#ifdef ZXD_DEBUG
	  fprintf(fdebug,"in[0..2] = %g, %g, %g\n", in[0],in[1],in[2]);
#endif
      if(pthis->spont > 5) p1 = 1;
      else p1 = 5/pthis->spont; /* Soft rectifying of sout */
      runsyn_dynamic(pthis,in,out,length);  
#ifdef ZXD_DEBUG
	  fprintf(fdebug,"out[0..2] = %g, %g, %g\n", out[0],out[1],out[2]);
#endif
  };

  /* Soft rectfying the sout (Cann't go to negative) */
  /* We use low-pass to soft-rectifier the waveform */
  for(i = 0; i<length;i++){
    temp = out[i]-shift;
	if(temp<=0)
		out[i] = +0.0;
	else
		out[i] = temp;
  };

  /* Method 2 : add low pass before we can go on the sout : the high frequency in ihc 
   * may be enhanced by the syanspse and then low passed by spike generator again */
/*  if(pthis->ifspike == 0){
    initLowPass(&syn_lowpass,pthis->tdres,1000.0,1.0,1);
    syn_lowpass.run2(&(syn_lowpass),out,out,length);
  };
*/
    initLowPass(&syn_lowpass,pthis->tdres,2000.0,1.0,1);
	/* Make the first output reasonable */
	syn_lowpass.run(&(syn_lowpass),out[0]);
	syn_lowpass.run(&(syn_lowpass),out[0]);
	syn_lowpass.run(&(syn_lowpass),out[0]);
	syn_lowpass.run2(&(syn_lowpass),out,out,length);

return;
};

double run1syn_dynamicNew(Tsynapse *pthis, double x)
{
  double out;
  runsyn_dynamicNew(pthis,&x,&out,1);
return out;
};

/* New initialization function */
int initSynapseNew2(Tsynapse *pthis, double spont_shift)
{
  int error = 0;
  double PTS,Ass,Aon,Ar_over_Ast,Ar,Ast;
  double Pimax,spont;
  double Prest;
  double CG,gamma1,gamma2,tauR,tauST,kappa1,kappa2,VI0,VI1,VI;
  double alpha,beta,theta1,theta2,theta3;
  double PL,PG,VL,Cirest,CLrest;

  double CLlast,CIlast,PPIlast;
  double tdres,CInow,CLnow;
  double shift; /* This is the shift I proposed */
  register int i;

  pthis->run = run1syn_dynamicNew;
  pthis->run2 = runsyn_dynamicNew;  /*This also need to be change !!!*/
  tdres = pthis->tdres;
  /*/begin the Synapse dynamic, according Paul's study, this is the best */
  /* shift = pthis->spont*2; */
  shift = spont_shift;
  pthis->shift = shift;

  Ass = pthis->Ass+shift;
  spont = pthis->spont+shift;
  
  Aon = pthis->PTS*pthis->Ass+shift;
/*  if(pthis->ifspike == 0) pthis->tauR = pthis->tauR*2; /* Now change the tauR */
/*  PTS = pthis->PTS; /* */
/*  Ass = pthis->Ass; /* For Human, from M. G. Heinz */
/*  Aon = PTS * Ass; */
  Ar_over_Ast = pthis->Ar_over_Ast;
  Ar = (Aon - Ass) * (Ar_over_Ast)/(1. + Ar_over_Ast);  /*/%???? Ar on both sides */
  Ast = Aon - Ass - Ar;

#ifdef ZXD_DEBUG

fprintf(fdebug,"\nspont=%g,Ass=%g,PTS=%g,Aon=%g,Ar=%g,Ast=%g",spont,Ass,pthis->PTS,Aon,Ar,Ast);  
fprintf(fdebug,"\nPimax = %g\n",pthis->Pimax);

#endif
  Pimax = pthis->Pimax;
/*  spont= pthis->spont; /* 50 in default */
  Prest = Pimax * spont/Aon;
  CG = spont * (Aon - spont)/(Aon * Prest*(1. - spont/Ass));
  gamma1 = CG/spont;
  gamma2 = CG/Ass;
  tauR= pthis->tauR;
  tauST= pthis->tauST;
  kappa1 = -( 1. /tauR);
  kappa2 = -( 1. /tauST);

  VI0 = (1.-Pimax/Prest)/(gamma1*(Ar*(kappa1-kappa2)/CG/Pimax+kappa2/Prest/gamma1-kappa2/Pimax/gamma2));
  VI1 = (1.-Pimax/Prest)/(gamma1*(Ast*(kappa2-kappa1)/CG/Pimax+kappa1/Prest/gamma1-kappa1/Pimax/gamma2));
  VI = (VI0 + VI1)/2.;

  alpha = gamma2/(kappa1 * kappa2);
  beta = -(kappa1 + kappa2) * alpha;
  theta1 = alpha * Pimax/VI;
  theta2 = VI/Pimax;
  theta3 = gamma2 - 1./Pimax;
  PL = (((beta - theta2 * theta3)/theta1) - 1.)*Pimax;
  PG = 1./(theta3 - 1./PL);
  VL = theta1 * PL * PG;
  Cirest = spont/Prest;
  CLrest = Cirest * (Prest + PL)/PL;
/*
  CIlast = Cirest;
  CLlast = CLrest;
  PPIlast = Prest;
  
  for(i = 0; i<length;i++){
    CInow = CIlast + (tdres/VI)*((-PPIlast*CIlast)+PL*(CLlast - CIlast));
    CLnow = CLlast + (tdres/VL)*(-PL*(CLlast-CIlast)+PG*(CG - CLlast));
    PPIlast = in[i];
    CIlast = CInow;
    CLlast = CLnow;
    out[i] = CInow*PPIlast;
  };
*/
  pthis->Prest = Prest;
  pthis->CIrest = Cirest;
  pthis->CLrest = CLrest;
  pthis->VI = VI;
  pthis->VL = VL;
  pthis->PL = PL;
  pthis->PG = PG;
  pthis->CG = CG;
  
  pthis->PPIlast = Prest;
  pthis->CLlast = CLrest;
  pthis->CIlast = Cirest;  
#ifdef ZXD_DEBUG

fprintf(fdebug,"\nPPI*CI=%g\n",pthis->CIlast*pthis->PPIlast);  

#endif
return(error);
};

