% This file compiles the matlab version of the ARLO auditory nerve model:
% Auditory nerve model for predicting performance limits of normal and impaired listeners
% Heinz, Zhang, Bruce, and Carney  ARLO (2001) 2:91-96.
%
% In addition, the version used in Nelson and Carney JASA (2004) vol 116
% with the modified synapse model and filter bandwidths for the linear
% sharp version of the model (model=3) is compiled


% This m-file only needs to be called once; the two functions will then be
% available for use.


% This creates the matlab function: an_arlo, which creates the sypnapse output
%    in response to an arbitrary input stimulus, scaled in pascals.
mex an_arlo.c cmpa.c hc.c complex.c filters.c synapse.c

% This creates the matlab function: an_arlo_newsyn, which creates the sypnapse output
%    in response to an arbitrary input stimulus, scaled in pascals.
mex an_arlo_newsyn.c cmpa.c hc.c complex.c filters.c synapse.c synapse_new.c

% This creates the matlab function sgmodel, which is a spike generation model.
mex sgmodel.c spikes.c

